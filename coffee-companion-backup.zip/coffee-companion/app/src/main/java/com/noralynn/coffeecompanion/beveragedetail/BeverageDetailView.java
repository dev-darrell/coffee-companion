package com.noralynn.coffeecompanion.beveragedetail;

import android.support.annotation.Nullable;

interface BeverageDetailView {

    void displayBeverage(@Nullable BeverageDetailModel beverage);

}
